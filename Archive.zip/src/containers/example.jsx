import { TableContainer } from "@mui/material";

<Grid item xs={12} md={8}>
  <TableContainer
    component={card}
    sx={{
      mr: 5,
      boxShadow: "0px 0px 20px rgba(0, 0, 0, 0.1)",
      mb: 5,
    }}
  >
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>Product</TableCell>
          <TableCell align="right">Name</TableCell>
          <TableCell align="right">Quantity</TableCell>
          <TableCell align="right">Price</TableCell>
          <TableCell align="right">Total</TableCell>
          <TableCell align="right"></TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        <View>
          {orders?.map((item) => {
            console.log("item", item);
            const { order_id, product_id, qty } = item;
            return (
              <View key={item?.order_id}>
                <Text>{item?.product_id?.name}</Text>
                <Text>{`Quantity: ${item?.qty}`}</Text>
                <Text>{`₹ ${item?.qty * item?.product_id?.price}`}</Text>
              </View>
            );
          })}
        </View>
      </TableBody>
    </Table>
  </TableContainer>
</Grid>;
