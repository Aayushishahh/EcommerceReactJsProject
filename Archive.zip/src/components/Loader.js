import React from "react";
import CircularProgress from "@mui/material/CircularProgress";
import { Backdrop } from "@mui/material";

const Loader = () => {
  return (
    // <div
    //   style={{
    //     display: "flex",
    //     justifyContent: "center",
    //     alignItems: "center",
    //     height: "100vh",
    //   }}
    // >
    // <div style={{position:'absolute',zIndex: 1}}> 

      <CircularProgress/>
      
     // </div>
  );
};

export default Loader;
